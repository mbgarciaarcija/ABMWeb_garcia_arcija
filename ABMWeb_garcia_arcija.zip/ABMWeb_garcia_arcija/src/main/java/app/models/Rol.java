package app.models;

import app.exceptions.DatoInvalidoException;
import java.util.List;
import org.javalite.activejdbc.Model;
import org.javalite.activejdbc.annotations.Table;

@Table("fichadas.roles")
public class Rol extends Model{

    public static List<Rol> listar(){
        List<Rol> roles = Rol
                .findAll();
        return roles;
    }
    public Rol() {
    }

    public static void validarRol(String identificador) throws DatoInvalidoException{
        //valida la existencia de un usuario en la base de datos
        try{
            int id=Integer.parseInt(identificador);
            Rol rol = Rol.findById(id);
            if (rol == null) {
                throw new DatoInvalidoException("El rol con el " + id + " no existe.");
            }
        }catch(NumberFormatException e){
            throw new DatoInvalidoException("El identificador " + identificador + " no es valido.");
        }
    }
    
}
