package app.models;

import app.exceptions.DatoInvalidoException;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.javalite.activejdbc.Model;
import org.javalite.activejdbc.annotations.BelongsTo;
import org.javalite.activejdbc.annotations.Table;

@Table("fichadas.usuarios")
@BelongsTo(foreignKeyName = "tipo_de_usuario", parent = Rol.class)
public class Usuario extends Model{
    //metodo utilizado para obtener el listado completo de usuarios y sus roles
    public static List<Usuario> listar(){
        List<Usuario> usuarios = Usuario
                .findAll()
                .include(Rol.class);
        return usuarios;
    }

    //Metodo utilizado para obtener el listado de usuarios que no posean fecha de baja
    public static List<Usuario> listarUsuariosActivos(){
        List<Usuario> usuarios = Usuario
                .where("fecha_baja IS NULL")
                .include(Rol.class);
        return usuarios;
    }

//metodo que obtiene a un usuario. Recibe el identificador del usuario
    public static Usuario obtenerUsuario(String id) {
        int uid= Integer.parseInt(id);
        Usuario usuario = Usuario.findById(uid);
        return usuario;
    }
    //metodo para obtener el rol que tiene relacionado el usuario
    public Rol getRol(){
        return parent(Rol.class);
    }
    //Constructor de la clase Usuario
    public Usuario() {
    }
//Metodo utilizado para obtener el alias de un usuario
    public static String obtenerAliasUsuario(int id){
        Usuario usuario = Usuario.findById(id);
        return usuario.getString("alias");
    }   
    //metodo para validar que el nombre o apellido recibidos desde el formulario solo tenga letras 
    //y una longitud entre 2 y 50 caracteres. Recibe una cadena que es el valor del nombre o apellido, 
    //y un campo que indica en el mensaje si se trata del nombre o del apellido
    //en caso de que la cadena no cumpla con la validacion, lanza una excepcion.
    public static void validarNombreApellido(String cadena, String campo) throws DatoInvalidoException {
        // Usamos una expresión regular para verificar si solo contiene letras
        if(!cadena.matches("^[a-zA-Z\\s]+$")){
            throw new DatoInvalidoException("El "+campo+" solo debe contener letras.");
        }
        if((cadena.length() < 2)||(cadena.length() > 50)){
            throw new DatoInvalidoException("El "+campo+" debe tener entre 2 y 50 caracteres.");
        }
        
    }
    
    //valida que el email cumpla con el formato algo@algo.algo y tenga una longitud entre 8 y 50 caracteres
    //recibe el valor del email a validar, y el nombre del campo ya que se utiliza con Email Principal y Email Secundario
    public static void validarEmail(String email, String campo) throws DatoInvalidoException {
        // Utilizamos una expresión regular para verificar el formato del email
        String patronEmail = "^[A-Za-z0-9+_.-]+@(.+)$";
        Pattern pattern = Pattern.compile(patronEmail);
        Matcher matcher = pattern.matcher(email);
        if(!matcher.matches()){
            throw new DatoInvalidoException("El "+campo+" no cumple con el formato de correo electronico.");
        }
        if((email.length() < 8)||(email.length() > 50)){
            throw new DatoInvalidoException("El "+campo+" debe tener entre 8 y 50 caracteres.");
        }
        
    }
    //Metodo que valida que la contrasenia contenga una minuscula, una mayuscula, y un numero
    //recibe como parametro la contrasenia a validar. Lanza una excepcion si no cumple con la validacion
    public static void validarContrasenia(String contrasenia) throws DatoInvalidoException {
        // Utilizamos una expresión regular para verificar la contraseña
        String patronContrasenia = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).+$";
        Pattern pattern = Pattern.compile(patronContrasenia);
        Matcher matcher = pattern.matcher(contrasenia);
        
        if(!matcher.matches()){
            throw new DatoInvalidoException("La contrasenia debe tener una letra minuscula, una letra mayuscula y un numero.");
        }
        if((contrasenia.length() < 8)||(contrasenia.length() > 25)){
            throw new DatoInvalidoException("La contrasenia debe tener entre 8 y 25 caracteres.");
        }
      }
    //metodo utilizado para validar que el alias no contenga espacios y tenga una longitud entre 3 y 25 caracteres.
    //Recibe el alias por argumento. Lanza una excepcion si el alias no cumple con la validacion.
    public static void validarAlias(String alias) throws DatoInvalidoException {
        if(alias.matches(".*\\s+.*")){
            throw new DatoInvalidoException("El alias no debe tener espacios en blanco.");
        }
        if((alias.length() < 3)||(alias.length() > 25)){
            throw new DatoInvalidoException("El alias debe tener entre 3 y 25 caracteres.");
        }
    }
    //metodo valida si el celular tiene una longitud de 8 a 15 caracteres y si es un numero.
    //Recibe una cadena que contiene el numero de celular. Lanza una excepcion si no cumple con las validaciones
    public static void validarCelular(String celularString) throws DatoInvalidoException {        
        if((celularString.length() < 8)||(celularString.length() > 15)){
            throw new DatoInvalidoException("El celular debe tener entre 8 y 15 digitos.");
        }
        try{
            long celular = Long.parseLong(celularString);
        }catch(NumberFormatException e){
            throw new DatoInvalidoException("El celular solo debe contener numeros.");
        }
        
    }
    //Metodo que obtiene los datos de los parametros y llama al validador correspondiente a cada dato.
    //recibe un mapa de datos con la informacion de los formularios de creacion y modificacion obtenida por parametros
    public static void validar(Map<String, String> datos) throws DatoInvalidoException {

        validarNombreApellido(datos.get("nombre"), "nombre");
        validarNombreApellido(datos.get("apellido"), "apellido");
        validarEmail(datos.get("email-principal"),"email principal");
        validarEmail(datos.get("email-secundario"),"email secundario");
        validarContrasenia(datos.get("contrasenia"));
        Rol.validarRol(datos.get("tipo-usuario"));
        validarAlias(datos.get("alias"));
        validarCelular(datos.get("numero-celular"));
        
    }
    //Metodo utilizado para realizar la validacion de los datos al momento de crear un usuario. Desde este metodo se invoca al metodo validar()
    //En caso de que se quiera utilizar el email principal o alias de algun otro usuario de la base de datos, lanza una excepcion
    public static void validarDatosCreacion(Map<String, String> datos) throws DatoInvalidoException {
        validar(datos);
       
        //- si el alias ya esta registrado en un usuario, muestra un error de alias no disponible.
        Usuario usuario = Usuario.findFirst("alias = ?", datos.get("alias"));
        if (usuario != null) {
            throw new DatoInvalidoException("El alias " + datos.get("alias") + " no esta disponible.");
        }
        //- si el mail ya esta registrado en un usuario activo, muestra un error de email no disponible.
        usuario = Usuario.findFirst("email_principal = ? AND fecha_baja IS NULL", datos.get("email-principal"));
        if (usuario != null) {
            throw new DatoInvalidoException("El email principal " + datos.get("email-principal") + " no esta disponible.");
        }
        
    }    

    //Metodo utilizado para realizar la validacion de los datos al momento de modificar un usuario. Desde este metodo se invoca al metodo validar()
    //En caso de que se quiera utilizar el email principal o alias de algun otro usuario de la base de datos, lanza una excepcion
    public static void validarDatosModificacion(Map<String, String> datos) throws DatoInvalidoException {
        try{
            int id=Integer.parseInt(datos.get("id"));
            
            validarUsuario(id);
            validar(datos);
            //- si el mail o alias ya estan registrados en un usuario que no sea el que tiene el mismo id, muestra un error.
            Usuario usuario = Usuario.findFirst("email_principal = ? AND id <> ?", datos.get("email-principal"), id);
            if (usuario != null) {
                throw new DatoInvalidoException("El email principal " + datos.get("email-principal") + " no esta disponible.");
            }
            usuario = Usuario.findFirst("alias = ? AND id <> ?", datos.get("alias"), id);
            if (usuario != null) {
                throw new DatoInvalidoException("El alias " + datos.get("alias") + " no esta disponible.");
            }
            
        }catch(NumberFormatException e){
            throw new DatoInvalidoException("El identificador " + datos.get("id") + " no es valido.");
        }   
    }
    
    //Metodo utilizado para realizar la validacion de la existencia de un usuario
    //Lanza una excepcion si el identificador del usuario no existe 
    public static void validarUsuario(int id) throws DatoInvalidoException{
        Usuario usuario = Usuario.findById(id);
        if (usuario == null) {
            throw new DatoInvalidoException("El usuario con el identificador " + id + " no existe.");
        }
    }
    
    //Metodo utilizado para realizar la creacion un usuario. 
//En caso de que el email principal este registrado en usuario dado de baja, se modifica dicho usuario y se lo restaura
//Si ningun otro usuario posee su email principal, se crea un nuevo usuario en la base de datos
// Recibe los datos del usuario. Lanza una excepcion si no se puede crear el usuario    
    public static void crear(Map<String, String> datos) throws DatoInvalidoException {
        try{
            //obtener fecha actual
            LocalDate fechaActual = LocalDate.now();
            int tipoUsuario=Integer.parseInt(datos.get("tipo-usuario"));
            long celular = Long.parseLong(datos.get("numero-celular"));

            //- si el email esta registrado en un usuario dado de baja, se restaura el antiguo usuario(los demas campos se modifican con los nuevos datos y el campo fecha baja se vuelve a colocar en null) 
            Usuario usuario = Usuario.findFirst("email_principal = ? AND fecha_baja IS NOT NULL", datos.get("email-principal"));
            if (usuario != null) {
                Usuario.update("nombre= ?, apellido = ?, "
                        + "alias = ?, contrasenia = ?, "
                        + "email_secundario = ?, nro_celular = ?, "
                        + "tipo_de_usuario = ?, fecha_alta = ?, "
                        + "fecha_baja = ?",
                        "id = ?",
                        datos.get("nombre"), datos.get("apellido"),
                        datos.get("alias"), datos.get("contrasenia"), 
                        datos.get("email-secundario"), celular, tipoUsuario, 
                        fechaActual, null, 
                        usuario.getId());
            
                  
            }else{//- si no esta registrado se crea.
                usuario = Usuario.create("nombre", datos.get("nombre")) 
                        .set("apellido", datos.get("apellido")) 
                        .set("alias", datos.get("alias"))
                        .set("contrasenia", datos.get("contrasenia")) 
                        .set("email_principal", datos.get("email-principal"))
                        .set("email_secundario", datos.get("email-secundario"))
                        .set("nro_celular", celular) 
                        .set("tipo_de_usuario", tipoUsuario) 
                        .set("fecha_alta", fechaActual);
                usuario.saveIt();
            }
        }catch(Exception e){
            throw new DatoInvalidoException("No se pudo crear al usuario. " + e.getMessage());        
        }

    }

    //Metodo utilizado para efectuar la modificacion de los datos de un usuario en la base de datos
    //Recibe un mapa que contiene todos los datos del usuario. Lanza una excepcion al no poder realizar la modificacion en la base de datos
    public static void modificar(Map<String, String> datos) throws DatoInvalidoException {
        try{
            int id=Integer.parseInt(datos.get("id"));
            int tipoUsuario=Integer.parseInt(datos.get("tipo-usuario"));
            long celular = Long.parseLong(datos.get("numero-celular"));

            Usuario usuario = Usuario.findById(id);
            Usuario.update("nombre= ?, apellido = ?, "
                        + "alias = ?, contrasenia = ?, "
                        + "email_principal = ?, email_secundario = ?, "
                        + "nro_celular = ?, tipo_de_usuario = ?",
                        "id = ?",
                        datos.get("nombre"), datos.get("apellido"),
                        datos.get("alias"), datos.get("contrasenia"), 
                        datos.get("email-principal"), datos.get("email-secundario"),
                        celular, tipoUsuario, 
                        usuario.getId());
            
        }catch(Exception e){
            throw new DatoInvalidoException("No se pudo realizar la modificacion. " + e.getMessage());        
        }
        
    }
    
    //Metodo utilizado para restaurar a un usuario en la base de datos luego de que sea dado de baja.
    //Modifica la fecha de alta del usuario con la fecha actual y la fecha de baja se setea en NULL
    //Recibe por parametros el identificador del usuario
    public static void restaurar(int id) {
        //obtener fecha actual
        LocalDate fechaActual = LocalDate.now();
        Usuario.update("fecha_alta = ?, fecha_baja = ?", "id = ?",fechaActual, null, id);
    }

    //Metodo utilizado para dar de baja logica a un usuario en la base de datos.
    //Modifica la fecha de baja del usuario con la fecha actual
    //Recibe por parametros el identificador del usuario
    public static void darBaja(int id){
        //obtener fecha actual
        LocalDate fechaActual = LocalDate.now();
        Usuario.update("fecha_baja= ?", "id = ?",fechaActual, id);                
    }
    
    //Metodo utilizado para realizar la eliminacion de un usuario en la base de datos 
    //Recibe el identificador del usuario
    public static void eliminar(int id){
        Usuario.delete("id = ?", id);                
    }

}
