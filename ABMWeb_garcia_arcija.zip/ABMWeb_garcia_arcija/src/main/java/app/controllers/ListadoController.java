package app.controllers;

import app.exceptions.DatoInvalidoException;
import app.models.Usuario;
import app.models.Rol;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.javalite.activeweb.AppController;
import org.javalite.activeweb.annotations.DELETE;
import org.javalite.activeweb.annotations.POST;
import org.javalite.activeweb.annotations.PUT;
import org.javalite.common.JsonHelper;

//Clase controlador
public class ListadoController extends AppController{
    //Controller action utilizado para mostrar la pagina inicial del controlador. Muestra un listado completo de los usuarios activos
    //Ademas muestra un formulario de creacion
    public void index(){
        List<Usuario> usuarios = Usuario.listarUsuariosActivos();
        view("usuarios", usuarios);
        List<Rol> roles = Rol.listar();
        view("roles", roles);

    }
    
    //Controller action utilizado para mostrar un listado con todos los usuarios almacenados en la base de datos
    //Ademas muestra un formulario de creacion
    public void listadoCompleto(){
        List<Usuario> usuarios = Usuario.listar();
        view("usuarios", usuarios);
           List<Rol> roles = Rol.listar();
        view("roles", roles);

    }
    
    //Controller action utilizado para mostrar los datos de un usuario
    public void ver(){
        Usuario usuario = Usuario.obtenerUsuario(param("id"));
        view("usuario", usuario);
    }
    
    //Controller action utilizado para mostrar un formulario de creacion de usuario en una vista aparte
    public void crearUsuario(){
        List<Rol> roles = Rol.listar();
        view("roles", roles);
    }
    
    //Controller action utilizado para restaurar a un usuario que se encuentra dado de baja. 
    //Recibe el identificador de un usuario para restaurarlo en la base de datos.
    //Contesta una cadena vacia si fue exitosa la restauracion. Contesta con un mensaje de error si
    //no pudo efectuarse la restauracion
    @PUT
    public void restaurarUsuario(){
        Map<String, String> errores = new HashMap<>();

        try{
            int id=Integer.parseInt(param("id"));
            Usuario.validarUsuario(id);
            Usuario.restaurar(id);
        }catch(NumberFormatException | DatoInvalidoException e){
           errores.put("error", e.getMessage());
           respond(JsonHelper.toJsonString(errores)).contentType("application/json").status(500);
            return;
        }
        respond("");
    }

    //Controller action utilizado para crear un usuario en la base de datos. 
    //Recibe desde un formulario todos los datos necesarios para la creacion del usuario
    //Contesta una cadena vacia si fue exitosa la creacion. Contesta con un mensaje de error si
    //no pudo efectuarse la creacion
    @POST
    public void crear(){
        Map<String, String> errores = new HashMap<>();
        
        try{
            Usuario.validarDatosCreacion(params1st());
            Usuario.crear(params1st());
        }catch(NumberFormatException | DatoInvalidoException e){
           errores.put("error", e.getMessage());
           respond(JsonHelper.toJsonString(errores)).contentType("application/json").status(500);
            return;
        }
        respond("");        
    }
    
    //Controller action utilizado para mostrar el formulario de modificacion con todos los datos 
    //actuales de un usuario alamacenado en la base de datos
    public void modificarUsuario(){
        Usuario datosUsuario = Usuario.obtenerUsuario(param("id"));
        List<Rol> roles = Rol.listar();
        view("usuario", datosUsuario);
        view("roles", roles);
    }
    //Controller action utilizado para modificar un usuario en la base de datos. 
    //Recibe desde un formulario todos los datos necesarios para la modificacion del usuario
    //Contesta una cadena vacia si fue exitosa la modificacion. Contesta con un mensaje de error si
    //no pudo efectuarse la modificacion
    @PUT
    public void modificar(){
        Map<String, String> errores = new HashMap<>();
        try{
            Usuario.validarDatosModificacion(params1st());
            Usuario.modificar(params1st());
        }catch(DatoInvalidoException e){
        //responder con un codigo de error 500 de error interno del servidor
           errores.put("error", e.getMessage());
           respond(JsonHelper.toJsonString(errores)).contentType("application/json").status(500);
            return;
        }
        //responder con un codigo 200
        respond("");
    }
    
    //Controller action utilizado para dar de baja a un usuario en la base de datos. 
    //Recibe desde un parametro de la URL el identificador del usuario
    //Contesta el alias del usuario si fue exitosa la baja logica del usuario. Contesta con un mensaje de error si
    //no pudo efectuarse la baja logica
    @PUT
    public void baja(){
        String ids = param("id");
        Map<String, String> errores = new HashMap<>();
        String alias="";
        try{
            int id = Integer.parseInt(ids);
            Usuario.validarUsuario(id);
            alias=Usuario.obtenerAliasUsuario(id);
            Usuario.darBaja(id);
        }catch(NumberFormatException | DatoInvalidoException e){
            errores.put("error", e.getMessage());
            respond(JsonHelper.toJsonString(errores)).contentType("application/json").status(500);
            return;
        }
        respond(alias);
    }
    
    //Controller action utilizado para eliminar a un usuario en la base de datos. 
    //Recibe desde un parametro de la URL el identificador del usuario
    //Contesta el alias del usuario si fue exitosa la eliminacion. Contesta con un mensaje de error si
    //no pudo efectuarse la eliminacion
    @DELETE
    public void borrar(){
        String ids = param("id");
        Map<String, String> errores = new HashMap<>();
        String alias="";
        try{
            int id = Integer.parseInt(ids);
            Usuario.validarUsuario(id);
            alias=Usuario.obtenerAliasUsuario(id);
            Usuario.eliminar(id);
        }catch(NumberFormatException | DatoInvalidoException e){
            errores.put("error", e.getMessage());
            respond(JsonHelper.toJsonString(errores)).contentType("application/json").status(500);
            return;
        }
        respond(alias);
    }
    
}
