package app.controllers;

import org.javalite.activeweb.controller_filters.HttpSupportFilter;

//Filtro utilizado para setear los valores de usuario y roles en session()
public class SesionFilter extends HttpSupportFilter{
    
    @Override
    public void before() {
        if(!sessionHas("usuario")){
            String usuario=getHttpServletRequest().getRemoteUser();
            Boolean rol_ver = getHttpServletRequest().isUserInRole("ver");
            Boolean rol_abm = getHttpServletRequest().isUserInRole("abm");
                
            if(rol_ver){
                if(rol_abm){
                    session("rol_abm", rol_abm);
                }
                session("rol_ver", rol_ver);
                session("usuario", usuario);
            }
        }
    }
}
