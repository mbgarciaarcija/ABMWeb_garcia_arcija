package app.controllers;

import org.javalite.activeweb.AppController;

//Clase controller utilizada para funcionar como ROOT del proyecto
public class HomeController extends AppController {

    //Controller Action utilizado par mostrar la pagina de bienvenida de la aplicacion
    public void index() {
    }
    //Controller Action utilizado para cerrar una session 
    public void logout() {
        session().invalidate();
        redirect();
    }
}
