package app.config;

import app.controllers.ListadoController;
import org.javalite.activeweb.AbstractRouteConfig;
import org.javalite.activeweb.AppContext;

public class RouteConfig extends AbstractRouteConfig {

    @Override
    public void init(AppContext appContext) {
        //route("/listado/").to(ListadoController.class).action("modificar").put();
    }
}
