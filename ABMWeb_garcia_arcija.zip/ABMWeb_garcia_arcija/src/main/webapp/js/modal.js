var context = window.location.pathname.split('/')[1];
//funcion que muestra el formulario de creacion com modal
function mostrarModal() {
    var modal = document.getElementById('modal');
    modal.style.display = 'block';
}
//funcion que cierra el formulario de creacion
function cerrarModal() {
    var modal = document.getElementById('modal');
    modal.style.display = 'none';
}

// Cierra el modal del formulario de creacion si se hace clic fuera del contenido
window.addEventListener('click', function(event) {
    var modal = document.getElementById('modal');
    if (event.target == modal) {
        modal.style.display = 'none';
    }
});

//funcion utilizada para validar que un id no este vacio y que contenga solo numeros
function validarId(id){
    if(!id){
        Swal.fire(
            'Operacion cancelada.',
            'No se encontro el identificador en los parametros.',
            'error'
        );
        return false;
    } else {
        var regex = /^[0-9]+$/;
        if (!regex.test(id)) {
            Swal.fire(
                'Operacion cancelada.',
                'El identificador debe contener solo numeros.',
                'error'
            );
            return false;
        } else {
            return true;
        }
    }
}
//funcion utilizada para validar que una contrasenia cumpla con una determinada longitud 
//y que contenga un numero, una minuscula y una mayuscula
function validarContrasenia(contrasenia){
    var regex = /^.{8,25}$/;

    if (!regex.test(contrasenia)) {
        Swal.fire(
            'Operacion cancelada.',
            'La contrasenia debe tener entre 8 y 25 caracteres.',
            'error'
        );
        return false;
    } else {
        var regex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])/;
        if (!regex.test(contrasenia)) {
            Swal.fire(
                'Operacion cancelada.',
                'La contrasenia debe contener un numero, una mayuscula y una minuscula.',
                'error'
            );
            return false;
        } else {
            return true;
        }
    }
}

//funcion utilizada para validar que el nombre o apellido cumpla con una determinada longitud 
//y que contenga solo letras
function validarNombreApellido(cadena, tipoDato){
    var regex = /^.{2,50}$/;

    if (!regex.test(cadena)) {
        Swal.fire(
            'Operacion cancelada.',
            'El '+tipoDato+' debe tener entre 2 y 50 caracteres.',
            'error'
        );
        return false;
    } else {
        var regex = /^[A-Za-z]+$/;
        if (!regex.test(cadena)) {
            Swal.fire(
                'Operacion cancelada.',
                'El '+tipoDato+' debe contener solo letras.',
                'error'
            );
            return false;
        } else {
            return true;
        }
    }
}

//funcion utilizada para validar que un email cumpla con una determinada longitud 
//y cumpla con el formato de los email
function validarEmail(cadena, tipoDato){
    var regex = /^.{8,50}$/;

    if (!regex.test(cadena)) {
        Swal.fire(
            'Operacion cancelada.',
            'El '+tipoDato+' debe tener entre 8 y 50 caracteres.',
            'error'
        );
        return false;
    } else {
        var regex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        if (!regex.test(cadena)) {
            Swal.fire(
                'Operacion cancelada.',
                'El '+tipoDato+' no tiene un formato valido.',
                'error'
            );
            return false;
        } else {
            return true;
        }
    }
}

//funcion utilizada para validar que un celular cumpla con una determinada longitud 
//y que contenga solo numeros
function validarCelular(celular){
    var regex = /^.{8,15}$/;

    if (!regex.test(celular)) {
        Swal.fire(
            'Operacion cancelada.',
            'El celular debe tener entre 8 y 15 digitos.',
            'error'
        );
        return false;
    } else {
        var regex = /^[0-9]+$/;
        if (!regex.test(celular)) {
            Swal.fire(
                'Operacion cancelada.',
                'El celular debe contener solo numeros.',
                'error'
            );
            return false;
        } else {
            return true;
        }
    }
}

//funcion utilizada para validar que un alias cumpla con una determinada longitud 
//y que no contenga espacios en blanco
function validarAlias(alias){
    var regex = /^.{3,25}$/;

    if (!regex.test(alias)) {
        Swal.fire(
            'Operacion cancelada.',
            'El alias debe tener entre 3 y 25 caracteres.',
            'error'
        );
        return false;
    } else {
        var regex = /^\S*$/;
        if (!regex.test(alias)) {
            Swal.fire(
                'Operacion cancelada.',
                'El alias no debe contener espacios en blanco.',
                'error'
            );
            return false;
        } else {
            return true;
        }
    }
}
function resaltar(campo){
    campo.addClass("form-error");
    campo.focus();
    
    // Obtén la posición vertical del campoNombre
    var posicion = campo.offset().top;
    
    // Realiza un desplazamiento suave (scroll) hasta la posición del campo
    $('html, body').animate({
        scrollTop: posicion
    }, 500); // 500 milisegundos para un desplazamiento suave
}
//funcion que lleva a cabo todas las validaciones en los campos del formulario creacion y 
//modificacion previo al envio de los datos al servidor
function validarForm(nombre, apellido, alias, emailPrincipal, contrasenia, emailSecundario, numeroCelular, tipoUsuario){
    
    if (!nombre || !apellido || !alias || !emailPrincipal || !contrasenia || !emailSecundario || !numeroCelular || !tipoUsuario) {
        // Al menos uno de los campos es nulo o vacío
        if(!tipoUsuario){
            Swal.fire(
                'Operacion cancelada.',
                'Seleccione un tipo de usuario.',
                'error'
            );
           
        }else{
            Swal.fire(
                'Operacion cancelada.',
                'Todos los campos son obligatorios. Complete los campos vacios',
                'error'
            );
        }
        return false;
    } else {
        if (!validarNombreApellido(nombre, 'nombre')) {
            resaltar($("input[name='nombre']"));
            return false;
        }
        
        if (!validarNombreApellido(apellido, 'apellido')) {
            resaltar($("input[name='apellido']"));
            return false;
        }
        
        if (!validarAlias(alias)) {
            resaltar($("input[name='alias']"));
            return false;
        }
        
        if (!validarEmail(emailPrincipal, 'Email Principal')) {
            resaltar($("input[name='email-principal']"));
            return false;
        }
        
        if (!validarContrasenia(contrasenia)) {
            resaltar($("input[name='contrasenia']"));     
            return false;
        }
        
        if (!validarEmail(emailSecundario, 'Email Secundario')) {
            resaltar($("input[name='email-secundario']"));
            return false;
        }
        
        if (!validarCelular(numeroCelular)) {
            resaltar($("input[name='numero-celular']"));
            return false;
        }
        
        return true;
    }
}

//funcion que quita la clase form-error de los componentes del formulario de creacion o modificacion
// luego de que se realice el envio del mismo
function removerClase(){
    $("input[name='nombre']").removeClass("form-error");
    $("input[name='apellido']").removeClass("form-error");
    $("input[name='alias']").removeClass("form-error");
    $("input[name='email-principal']").removeClass("form-error");
    $("input[name='contrasenia']").removeClass("form-error");
    $("input[name='email-secundario']").removeClass("form-error");
    $("input[name='numero-celular']").removeClass("form-error");
    $("#tipo-usuario").removeClass("form-error"); 
}
//funcion utilizada para enviar al servidor los datos del usuario que se desea crear
function crear(){
    removerClase();
    // Captura los valores de los campos de entrada
    var nombre = $("input[name='nombre']").val();
    var apellido = $("input[name='apellido']").val();
    var alias = $("input[name='alias']").val();
    var emailPrincipal = $("input[name='email-principal']").val();
    var contrasenia = $("input[name='contrasenia']").val();
    var emailSecundario = $("input[name='email-secundario']").val();
    var numeroCelular = $("input[name='numero-celular']").val();
    var tipoUsuario = $("#tipo-usuario").val(); 
    
    if (validarForm(nombre, apellido, alias, emailPrincipal, contrasenia, emailSecundario, numeroCelular, tipoUsuario)) {
        var parametros='?nombre='+nombre+'&apellido='+apellido+'&alias='+alias+'&email-principal='+emailPrincipal+'&contrasenia='+contrasenia+'&email-secundario='+emailSecundario+'&numero-celular='+numeroCelular+'&tipo-usuario='+tipoUsuario;

        // Realiza la solicitud AJAX
        $.ajax({
            url: 'crear'+parametros,
            type: 'POST', 
            success: function(data) {
                Swal.fire({
                    title: 'Operacion exitosa',
                    text: 'El usuario '+alias+' ha sido creado',
                    icon: 'success',
                    confirmButtonText: 'OK'
                }).then(function () {
                    window.location.href = '../listado'; // Recargar la página
                });
                },
            error: function(xhr, status, error) {
                // Maneja errores
                var errorMessage = "Ocurrio un error desconocido.";

                if (xhr.responseJSON && xhr.responseJSON.error) {
                    errorMessage = xhr.responseJSON.error; 
                }

                Swal.fire({
                    title: 'Error',
                    text: 'Causa: '+errorMessage,
                    icon: 'error',
                    confirmButtonText: 'OK'
                });
            }
        });
    }
}; 

//funcion utilizada para enviar al servidor los nuevos datos del usuario que se desea modificar
function modificar(){
    removerClase();
    // Captura los valores de los campos de entrada
    var id = $("input[name='id']").val();
    var nombre = $("input[name='nombre']").val();
    var apellido = $("input[name='apellido']").val();
    var alias = $("input[name='alias']").val();
    var emailPrincipal = $("input[name='email-principal']").val();
    var contrasenia = $("input[name='contrasenia']").val();
    var emailSecundario = $("input[name='email-secundario']").val();
    var numeroCelular = $("input[name='numero-celular']").val();
    var tipoUsuario = $("#tipo-usuario").val(); 
    
    if(validarId(id)){
    
        if (validarForm(nombre, apellido, alias, emailPrincipal, contrasenia, emailSecundario, numeroCelular, tipoUsuario)) {

            var parametros='?id='+id+'&nombre='+nombre+'&apellido='+apellido+'&alias='+alias+'&email-principal='+emailPrincipal+'&contrasenia='+contrasenia+'&email-secundario='+emailSecundario+'&numero-celular='+numeroCelular+'&tipo-usuario='+tipoUsuario;

            // Realiza la solicitud AJAX
            $.ajax({
                url: '../modificar'+parametros,
                type: 'PUT', 
                success: function(data) {
                    Swal.fire({
                        title: 'Operacion exitosa',
                        text: 'El usuario '+alias+' ha sido modificado',
                        icon: 'success',
                        confirmButtonText: 'OK'
                    }).then(function () {
                        window.location.href = '../'; // Recargar la página
                    });
                },
                error: function(xhr, status, error) {
                    // Maneja errores
                    var errorMessage = "Ocurrio un error desconocido.";

                    if (xhr.responseJSON && xhr.responseJSON.error) {
                        errorMessage = xhr.responseJSON.error; 
                    }

                    Swal.fire({
                        title: 'Error',
                        text: 'Causa: '+errorMessage,
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
                }
            });
        }
    }
};

//funcion utilizada para indicar al servidor el usuario se desea eliminar de la base de datos
function eliminar(id){
    if(validarId(id)){
        Swal.fire({
            title:"¿Desea eliminar al usuario?",
            text:"No se podran recuperar los datos luego de esto.",
            icon:"warning",
            showCancelButton: true,
            confirmButtonText: 'Eliminar',
            cancelButtonText: 'Volver',
            reverseButtons: true
        }).then((result) => {
            if (result.isConfirmed) {
                var ruta="../../"+ context +"/listado/borrar/"+id;
                $.ajax({
                    url:ruta,
                    type:"DELETE",
                    success:function(data){
                        Swal.fire({
                            title: 'Operacion exitosa',
                            text: 'El usuario '+data+' ha sido eliminado',
                            icon: 'success',
                            confirmButtonText: 'OK'
                        }).then(function () {
                            location.reload(); // Recargar la página
                        });
                    },
                    error: function(xhr, status, error) {
                      // Maneja errores
                        var errorMessage = "Ocurrio un error desconocido.";

                        if (xhr.responseJSON && xhr.responseJSON.error) {
                            errorMessage = xhr.responseJSON.error; 
                        }

                        Swal.fire({
                            title: 'Error',
                            text: errorMessage,
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });
                    }
                });
            } else if (
                result.dismiss === Swal.DismissReason.cancel
            ) {
                Swal.fire(
                    'Operacion cancelada.',
                    'Los datos del usuario estan a salvo :)',
                    'error'
                );
            }
        });
    }
};

//funcion utilizada para indicar al servidor el usuario se desea eliminar de la base de datos. 
//Utilizada para eliminar desde la visualizacion de los datos del usuario.
function eliminarU(id){
    if(validarId(id)){
        Swal.fire({
            title:"¿Desea eliminar al usuario?",
            text:"No se podran recuperar los datos luego de esto.",
            icon:"warning",
            showCancelButton: true,
            confirmButtonText: 'Eliminar',
            cancelButtonText: 'Volver',
            reverseButtons: true
        }).then((result) => {
            if (result.isConfirmed) {
                var ruta="../../../"+ context +"/listado/borrar/"+id;
                $.ajax({
                    url:ruta,
                    type:"DELETE",
                    success:function(data){
                        Swal.fire({
                            title: 'Operacion exitosa',
                            text: 'El usuario '+data+' ha sido eliminado',
                            icon: 'success',
                            confirmButtonText: 'OK'
                        }).then(function () {
                            window.location.href = '../'; // Recargar la página
                        });
                    },
                    error: function(xhr, status, error) {
                      // Maneja errores
                        var errorMessage = "Ocurrio un error desconocido.";

                        if (xhr.responseJSON && xhr.responseJSON.error) {
                            errorMessage = xhr.responseJSON.error; 
                        }

                        Swal.fire({
                            title: 'Error',
                            text: errorMessage,
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });
                    }
                });
            } else if (
                result.dismiss === Swal.DismissReason.cancel
            ) {
                Swal.fire(
                    'Operacion cancelada.',
                    'Los datos del usuario estan a salvo :)',
                    'error'
                );
            }
        });
    }
};

//funcion utilizada para indicar al servidor que realice la baja logica de un usuario en la base de datos
function baja(id){
    if(validarId(id)){
        Swal.fire({
            title:"¿Desea dar de baja al usuario?",
            text:"Luego puede restaurarse el usuario.",
            icon:"warning",
            showCancelButton: true,
            confirmButtonText: 'Dar de baja',
            cancelButtonText: 'Volver',
            reverseButtons: true
        }).then((result) => {
            if (result.isConfirmed) {
                var ruta="../../"+ context +"/listado/baja/"+id;
                $.ajax({
                    url:ruta,
                    type:"PUT",
                    success:function(data){
                        Swal.fire({
                            title: 'Operacion exitosa',
                            text: 'El usuario '+data+' ha sido dado de baja',
                            icon: 'success',
                            confirmButtonText: 'OK'
                        }).then(function () {
                            location.reload(); // Recargar la página
                        });
                    },
                    error: function(xhr, status, error) {
                      // Maneja errores
                        var errorMessage = "Ocurrio un error desconocido.";

                        if (xhr.responseJSON && xhr.responseJSON.error) {
                            errorMessage = xhr.responseJSON.error; 
                        }

                        Swal.fire({
                            title: 'Error',
                            text: errorMessage,
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });
                    }
                });
            } else if (
                result.dismiss === Swal.DismissReason.cancel
            ) {
                Swal.fire(
                    'Operacion cancelada.',
                    'Los datos del usuario estan a salvo :)',
                    'error'
                );
            }
        });
    }
};

//funcion utilizada para indicar al servidor que realice la baja logica de un usuario en la base de datos.
//Se utiliza en la seccion de visualizacion de los datos del usuario
function bajaU(id){
    if(validarId(id)){
        Swal.fire({
            title:"¿Desea dar de baja al usuario?",
            text:"Luego puede restaurarse el usuario.",
            icon:"warning",
            showCancelButton: true,
            confirmButtonText: 'Dar de baja',
            cancelButtonText: 'Volver',
            reverseButtons: true
        }).then((result) => {
            if (result.isConfirmed) {
                var ruta="../../../"+ context +"/listado/baja/"+id;
                $.ajax({
                    url:ruta,
                    type:"PUT",
                    success:function(data){
                        Swal.fire({
                            title: 'Operacion exitosa',
                            text: 'El usuario '+data+' ha sido dado de baja',
                            icon: 'success',
                            confirmButtonText: 'OK'
                        }).then(function () {
                            window.location.href = '../'; // Recargar la página                    
                        });
                    },
                    error: function(xhr, status, error) {
                      // Maneja errores
                        var errorMessage = "Ocurrio un error desconocido.";

                        if (xhr.responseJSON && xhr.responseJSON.error) {
                            errorMessage = xhr.responseJSON.error; 
                        }

                        Swal.fire({
                            title: 'Error',
                            text: errorMessage,
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });
                    }
                });
            } else if (
                result.dismiss === Swal.DismissReason.cancel
            ) {
                Swal.fire(
                    'Operacion cancelada.',
                    'Los datos del usuario estan a salvo :)',
                    'error'
                );
            }
        });
    }
};

//funcion utilizada para indicar al servidor que realice la restauracion de un usuario dado de baja en la base de datos.
//Se utiliza en la seccion de visualizacion de los datos del usuario
function restaurarU(id){
    if(validarId(id)){
        var ruta="../../../"+ context +"/listado/restaurar_usuario/"+id;
        $.ajax({
            url:ruta,
            type:"PUT",
            success:function(data){
                Swal.fire({
                    title: 'Operacion exitosa',
                    text: 'El usuario '+data+' ha sido restaurado',
                    icon: 'success',
                    confirmButtonText: 'OK'
                }).then(function () {
                    window.location.href = '../'; // Recargar la página
                });
            },
            error: function(xhr, status, error) {
                // Maneja errores
                var errorMessage = "Ocurrio un error desconocido.";

                if (xhr.responseJSON && xhr.responseJSON.error) {
                    errorMessage = xhr.responseJSON.error; 
                }

                Swal.fire({
                    title: 'Error',
                    text: errorMessage,
                    icon: 'error',
                    confirmButtonText: 'OK'
                });
            }
        });
    }
};

//funcion utilizada para indicar al servidor que realice la restauracion de un usuario dado de baja en la base de datos.
function restaurar(id){
    if(validarId(id)){

        var ruta="../../"+ context +"/listado/restaurar_usuario/"+id;
        $.ajax({
            url:ruta,
            type:"PUT",
            success:function(data){
                Swal.fire({
                    title: 'Operacion exitosa',
                    text: 'El usuario '+data+' ha sido restaurado',
                    icon: 'success',
                    confirmButtonText: 'OK'
                }).then(function () {
                            location.reload(); // Recargar la página
                });
            },
            error: function(xhr, status, error) {
                // Maneja errores
                var errorMessage = "Ocurrio un error desconocido.";

                if (xhr.responseJSON && xhr.responseJSON.error) {
                    errorMessage = xhr.responseJSON.error; 
                }

                Swal.fire({
                    title: 'Error',
                    text: errorMessage,
                    icon: 'error',
                    confirmButtonText: 'OK'
                });
            }
        });
    }
};